import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class SpiceApp extends JFrame {
    private SpiceBackend backend = new SpiceBackend();
    private JTable table;
    private DefaultTableModel tableModel;

    // Inputs
    private JTextField nameField, priceField, qtyField, searchField;

    public SpiceApp() {
        setTitle("Spice Inventory System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Load data on start
        backend.loadFromFile();

        // --- TOP PANEL (Inputs + Search) ---
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        
        // Row 1: Add New Spice Inputs
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField(10);
        inputPanel.add(nameField);
        
        inputPanel.add(new JLabel("Price:"));
        priceField = new JTextField(6);
        inputPanel.add(priceField);
        
        inputPanel.add(new JLabel("Qty:"));
        qtyField = new JTextField(6);
        inputPanel.add(qtyField);

        JButton btnAdd = new JButton("Add Spice");
        inputPanel.add(btnAdd);
        
        // Row 2: Search Bar
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(new JLabel("Search Spice:"));
        searchField = new JTextField(15);
        searchPanel.add(searchField);
        JButton btnSearch = new JButton("Search");
        JButton btnReset = new JButton("Show All");
        searchPanel.add(btnSearch);
        searchPanel.add(btnReset);

        topPanel.add(inputPanel);
        topPanel.add(searchPanel);
        add(topPanel, BorderLayout.NORTH);

        // --- CENTER (Table) ---
        String[] columns = {"Spice Name", "Price (Rs/kg)", "Quantity (kg)"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- BOTTOM (Actions) ---
        JPanel buttonPanel = new JPanel();
        JButton btnUpdate = new JButton("Update Qty");
        JButton btnRemove = new JButton("Remove Selected");
        JButton btnSort = new JButton("Sort Price");
        JButton btnClearAll = new JButton("Clear ALL");
        JButton btnSave = new JButton("Save Data");

        btnClearAll.setForeground(Color.RED);

        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnRemove);
        buttonPanel.add(btnSort);
        buttonPanel.add(btnClearAll);
        buttonPanel.add(new JSeparator(SwingConstants.VERTICAL));
        buttonPanel.add(btnSave);
        add(buttonPanel, BorderLayout.SOUTH);

        // ================= EVENTS =================

        // 1. ADD
        btnAdd.addActionListener(e -> {
            try {
                String name = nameField.getText();
                if(name.isEmpty()) return;
                double price = Double.parseDouble(priceField.getText());
                double qty = Double.parseDouble(qtyField.getText());
                String res = backend.addSpice(name, price, qty);
                if(res.equals("Success")) {
                    refreshTable(backend.getSpices());
                    nameField.setText(""); priceField.setText(""); qtyField.setText("");
                } else JOptionPane.showMessageDialog(this, res);
            } catch(Exception ex) { JOptionPane.showMessageDialog(this, "Invalid Numbers"); }
        });

        // 2. SEARCH LOGIC
        btnSearch.addActionListener(e -> {
            String query = searchField.getText();
            ArrayList<Spice> results = backend.searchSpices(query);
            refreshTable(results);
        });

        btnReset.addActionListener(e -> {
            searchField.setText("");
            refreshTable(backend.getSpices());
        });

        // 3. CLEAR ALL LOGIC
        btnClearAll.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Delete EVERYTHING? This cannot be undone.", "Warning", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                backend.clearAll();
                refreshTable(backend.getSpices());
            }
        });

        // 4. UPDATE
        btnUpdate.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String name = (String) tableModel.getValueAt(row, 0);
                String val = JOptionPane.showInputDialog("New Quantity for " + name + ":");
                if(val != null) {
                    try { backend.updateSpiceQuantity(name, Double.parseDouble(val)); refreshTable(backend.getSpices()); }
                    catch(Exception ex) { JOptionPane.showMessageDialog(this, "Invalid Number"); }
                }
            }
        });

        // 5. REMOVE SINGLE
        btnRemove.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String name = (String) tableModel.getValueAt(row, 0);
                backend.removeSpice(name);
                refreshTable(backend.getSpices());
            }
        });

        // 6. SORT
        btnSort.addActionListener(e -> {
            backend.sortSpicesByPrice();
            refreshTable(backend.getSpices());
        });

        // 7. SAVE
        btnSave.addActionListener(e -> JOptionPane.showMessageDialog(this, backend.saveToFile()));

        refreshTable(backend.getSpices());
        setVisible(true);
    }

    private void refreshTable(ArrayList<Spice> list) {
        tableModel.setRowCount(0);
        for (Spice s : list) {
            tableModel.addRow(s.toRow());
        }
    }

    // ==========================================================
    // !!! THIS IS THE MAIN METHOD. IT MUST BE HERE !!!
    // ==========================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SpiceApp());
    }
}