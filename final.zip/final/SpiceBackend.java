import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class SpiceBackend {
    private final ArrayList<Spice> spices = new ArrayList<>();

    public ArrayList<Spice> getSpices() {
        return spices;
    }

    // --- SEARCH ---
    public ArrayList<Spice> searchSpices(String query) {
        ArrayList<Spice> results = new ArrayList<>();
        for (Spice s : spices) {
            if (s.getName().toLowerCase().contains(query.toLowerCase())) {
                results.add(s);
            }
        }
        System.out.println("Search completed. Found " + results.size() + " matches.");
        return results;
    }

    // --- CLEAR ALL ---
    public void clearAll() {
        spices.clear();
        System.out.println("All spices deleted successfully.");
    }

    // --- ADD SPICE ---
    public String addSpice(String name, double price, double quantity) {
        for (Spice s : spices) {
            if (s.getName().equalsIgnoreCase(name)) {
                System.out.println("Error: Spice '" + name + "' already exists.");
                return "Error: Spice already exists!";
            }
        }
        spices.add(new Spice(name, price, quantity));
        System.out.println("Spice '" + name + "' added successfully.");
        return "Success";
    }

    // --- REMOVE SPICE ---
    public String removeSpice(String name) {
        Spice toRemove = null;
        for (Spice s : spices) {
            if (s.getName().equalsIgnoreCase(name)) {
                toRemove = s;
                break;
            }
        }
        if (toRemove != null) {
            spices.remove(toRemove);
            System.out.println("Spice '" + name + "' removed successfully.");
            return "Spice removed.";
        }
        System.out.println("Error: Spice '" + name + "' not found.");
        return "Spice not found.";
    }

    // --- UPDATE QUANTITY ---
    public void updateSpiceQuantity(String name, double newQty) {
        for (Spice s : spices) {
            if (s.getName().equalsIgnoreCase(name)) {
                s.setQuantity(newQty);
                System.out.println("Quantity for '" + name + "' updated successfully.");
                return;
            }
        }
        System.out.println("Error: Could not update. Spice not found.");
    }

    // --- SORT ---
    public void sortSpicesByPrice() {
        int n = spices.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (spices.get(j).getPrice() > spices.get(j + 1).getPrice()) {
                    Spice temp = spices.get(j);
                    spices.set(j, spices.get(j + 1));
                    spices.set(j + 1, temp);
                }
            }
        }
        System.out.println("Spices sorted by price successfully.");
    }

    // --- SAVE TO FILE ---
    public String saveToFile() {
        try {
            PrintWriter writer = new PrintWriter("spices.txt");
            for (Spice s : spices) {
                writer.println(s.getName() + "," + s.getPrice() + "," + s.getQuantity());
            }
            writer.close();
            System.out.println("Data saved to file successfully.");
            return "Data saved successfully!";
        } catch (Exception e) {
            System.out.println("Error: Could not save file.");
            return "Error saving file.";
        }
    }

    // --- LOAD FROM FILE ---
    public void loadFromFile() {
        try {
            File file = new File("spices.txt");
            if (file.exists()) {
                Scanner fileScanner = new Scanner(file);
                spices.clear();
                while (fileScanner.hasNextLine()) {
                    String line = fileScanner.nextLine();
                    String[] data = line.split(",");
                    if (data.length == 3) {
                        spices.add(new Spice(data[0], Double.parseDouble(data[1]), Double.parseDouble(data[2])));
                    }
                }
                fileScanner.close();
                System.out.println("Data loaded successfully.");
            } else {
                System.out.println("No previous data found. Starting fresh.");
            }
        } catch (Exception e) {
            System.out.println("Error loading file.");
        }
    }
}