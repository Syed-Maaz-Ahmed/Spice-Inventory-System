public class Spice {
    private final String name;
    private final double price;
    private double quantity;

    public Spice(String name, double price, double quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public Object[] toRow() {
        return new Object[]{name, price, quantity};
    }
}